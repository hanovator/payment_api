//
//  PaymentWebViewController.h
//  NicePayAppSample
//
//  Created by xoghzone on 2019. 1. 9..
//  Copyright © 2019년 Nicepayments. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PaymentWebViewController : UIViewController
<WKNavigationDelegate>

@property(nonatomic, weak)IBOutlet UIActivityIndicatorView *activityView;

@property(nonatomic, strong)WKWebView *webView;
@property(nonatomic, strong)NSString *bankPayUrlString;

- (void)callbyOpenUrl:(NSURL*)url1;

@end

NS_ASSUME_NONNULL_END
