//
//  PaymentWebViewController.m
//  NicePayAppSample
//
//  Created by xoghzone on 2019. 1. 9..
//  Copyright © 2019년 Nicepayments. All rights reserved.
//

#import "PaymentWebViewController.h"

#define APP_SCHEME      @"nicepaysample://"
#define PAY_URL         @"https://web.nicepay.co.kr/smart/mainPay.jsp"

@interface PaymentWebViewController ()

@end

@implementation PaymentWebViewController

//------------------------------------------------------------------------------------------
//
// Delegate
//
//------------------------------------------------------------------------------------------
#pragma mark - Delegate

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    [self.activityView startAnimating];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [self.activityView stopAnimating];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    [self.activityView stopAnimating];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    NSURLRequest *request = navigationAction.request;
    
    //현재 URL을 읽음
    NSString *URLString = [NSString stringWithString:[request.URL absoluteString]];
    
    //NSLog(@"current URL %@", URLString);
    
    //app store URL 여부 확인
    BOOL goAppStore1 = ([URLString rangeOfString:@"phobos.apple.com" options:NSCaseInsensitiveSearch].location != NSNotFound);
    BOOL goAppStore2 = ([URLString rangeOfString:@"itunes.apple.com" options:NSCaseInsensitiveSearch].location != NSNotFound);
    
    //app store 로 연결하는 경우 앱스토어 APP을 열어 준다. (isp, bank app 이 설치하고자 경우)
    if( goAppStore1 || goAppStore2 ) {
        [[UIApplication sharedApplication] openURL:request.URL];
        decisionHandler(WKNavigationActionPolicyCancel);
        return;
    }
    
    //isp App을 호출하는 경우
    if( [URLString hasPrefix:@"ispmobile://"] ) {
        //앱이 설치 되어 있는 확인
        if( ![[UIApplication sharedApplication] canOpenURL:request.URL] ) {  //설치 되어 있을 경우 isp App 호출
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림"
                                                                           message:@"모바일 ISP가 설치되어 있지 않아\nApp Store로 이동합니다."
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *ok = [UIAlertAction actionWithTitle:@"확인"
                                                         style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *action) {
                                                           [self installIsp];
                                                       }];
            [alert addAction:ok];
            [self presentViewController:alert animated:YES completion:nil];
            decisionHandler(WKNavigationActionPolicyCancel);
            return;
        }
    }
    
    //계좌이체
    if( [URLString hasPrefix:@"kftc-bankpay://"] ) {
        //앱이 설치 되어 있는 확인
        if( [[UIApplication sharedApplication] canOpenURL:request.URL] ) {
            // 설치되어있다면 callbackparam1에 담긴 값을 얻기위해 작업
            // callbackparam1은 나이스에서 제공하는 리턴 URL이므로
            // 아래와 같이 NSLog를 통해 해당 부분이 잘 리턴되는지 필히 체크해보시길 바랍니다.
            NSArray *urlParams = [URLString componentsSeparatedByString:@"&"];
            for( NSString* nameValue in urlParams ) {
                NSArray* nv = [nameValue componentsSeparatedByString:@"="];
                if( [nv containsObject:@"callbackparam1"] ) {
                    for( NSString *value in nv ) {
                        if( ![value isEqualToString:@"callbackparam1"] ) {
                            // URL인코딩 되어 리턴됩니다.
                            // 해당 스테이지에서 디코딩 해주셔도 문제 없습니다.
                            // 다만 디코딩하시면 requestBankPayResult메소드에서 하는 디코딩 작업을 삭제해주세요.
                            // 해당 부분 변경하지 않으실 것이라면 그대로 해당 스트링에 담아두시면 됩니다.
                            self.bankPayUrlString = value;
                        }
                    }
                }
            }
        } else {
            //설치 되어 있지 않다면 app store 연결
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림"
                                                                           message:@"Bank Pay가 설치되어 있지 않아\nApp Store로 이동합니다."
                                                                        preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *ok = [UIAlertAction actionWithTitle:@"확인"
                                                         style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *action) {
                                                           [self installBankPay];
                                                       }];
            [alert addAction:ok];
            [self presentViewController:alert animated:YES completion:nil];
            decisionHandler(WKNavigationActionPolicyCancel);
            return;
        }
    }
    
    if( ![URLString hasPrefix:@"http://"] && ![URLString hasPrefix:@"https://"] ) {
        if( [[UIApplication sharedApplication] canOpenURL:request.URL] ) {
            //urlscheme, tel, mailto, etc.
            [[UIApplication sharedApplication] openURL:request.URL];
            //decisionHandler(WKNavigationActionPolicyCancel);
            //return;
        }
    }
    
    decisionHandler(WKNavigationActionPolicyAllow);
}

//------------------------------------------------------------------------------------------
//
// ViewController
//
//------------------------------------------------------------------------------------------
#pragma mark - ViewController

- (void)dealloc {
    [self.bankPayUrlString release];
    [self.webView release];
    
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"구매하기";
    
    self.webView = [[[WKWebView alloc] init] autorelease];
    self.webView.navigationDelegate = self;
    [self.view addSubview:self.webView];
    
    [self.view bringSubviewToFront:self.activityView];
    
    [self loadUrl:PAY_URL];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    self.webView.frame = self.view.frame;
}

//------------------------------------------------------------------------------------------
//
// Private
//
//------------------------------------------------------------------------------------------
#pragma mark - Private

- (void)loadUrl:(NSString*)strUrl {
    //nicepay 결제테스트 URL 입니다.
    //제공 된 샘플 상 payRequest 스크립트 페이지를 참고 하시여 개발 하시면 됩니다.
    /*
     // 앱에서 연동 시 결제 요청 페이지에 가맹점 APP Scheme 명을 설정 하여 주시기 바랍니다.
     <input type="hidden" name="WapUrl"  value="nicepaysample"/>     // ISP 및 계좌이체 리턴 URL(앱에서 호출하는 경우 App Scheme)
     <input type="hidden" name="IspCancelUrl"  value="nicepaysample://ISPCancel"/>     ISP 취소 URL(앱에서 호출하는 경우 App Scheme)
     */
    
    NSURL *url = [[NSURL alloc] initWithString:strUrl];
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
    [url release];
}

- (void)installIsp {
    NSString *URLString = @"http://itunes.apple.com/kr/app/id369125087?mt=8";
    NSURL *storeURL = [NSURL URLWithString:URLString];
    [[UIApplication sharedApplication] openURL:storeURL];
}

- (void)installBankPay {
    NSString *URLString = @"http://itunes.apple.com/us/app/id398456030?mt=8";
    NSURL *storeURL = [NSURL URLWithString:URLString];
    [[UIApplication sharedApplication] openURL:storeURL];
}

- (void)resultIsp:(NSString*)urlString {
    NSURL *url = [NSURL URLWithString: urlString];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: url];
    [request setHTTPMethod: @"GET"];
    [self.webView loadRequest: request];
    [request release];
}

- (void)resultBankPay:(NSString*)urlString {
    //NSString *strUrl = [self.bankPayUrlString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *strUrl = [self.bankPayUrlString stringByRemovingPercentEncoding];
    if( @available(iOS 11, *) ) {
        NSURL *url = [NSURL URLWithString:strUrl];
        NSLog(@"BANK URL: %@", url);
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPMethod: @"POST"];
        [request setHTTPBody: [urlString dataUsingEncoding: NSUTF8StringEncoding]];
        [self.webView loadRequest: request];
        [request release];
    } else {
        strUrl = [strUrl stringByAppendingString:@"?"];
        strUrl = [strUrl stringByAppendingString:urlString];
        NSURL *url = [NSURL URLWithString:strUrl];
        NSLog(@"BANK URL: %@", url);
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: url];
        [request setHTTPMethod: @"GET"];
        [self.webView loadRequest: request];
        [request release];
    }
}

//------------------------------------------------------------------------------------------
//
// Public
//
//------------------------------------------------------------------------------------------
#pragma mark - Public

- (void)callbyOpenUrl:(NSURL*)url {
    NSString *URLkeyString = [NSString stringWithString:[url absoluteString]];
    
    NSLog(@"URLkey : %@", URLkeyString);
    
    //scheme를 통한 호출 여부
    if( URLkeyString ) {
        if( [URLkeyString hasPrefix:APP_SCHEME] ) {
            NSRange range = [URLkeyString rangeOfString:@"?bankpaycode"];    //계좌이체 인경우
            if( range.location != NSNotFound ) { //계좌이체 인증 후 거래 진행
                //[MY_APP_URL_KEY length]+1 => 계좌이체인 경우  scheme + ? 로 리던 되어 "?" 도 함께 삭제 함.
                //nicepaysample://?bankpaycode=xxxx ...." 에서 "bankpaycode=xxxx ...." 추출하기 위함
                URLkeyString = [URLkeyString substringFromIndex:[APP_SCHEME length]+1];
                [self resultBankPay:URLkeyString];
                return;
            }
            
            //결제 요청 필드 내
            range = [URLkeyString rangeOfString:@"ISPCancel"];
            if( range.location != NSNotFound ) { //ISP 취소인 경우
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림"
                                                                               message:@"결제를 취소하셨습니다."
                                                                        preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction *ok = [UIAlertAction actionWithTitle:@"확인"
                                                             style:UIAlertActionStyleDefault
                                                           handler:^(UIAlertAction *action) {
                                                               [self.navigationController popViewControllerAnimated:YES];
                                                           }];
                [alert addAction:ok];
                [self presentViewController:alert animated:YES completion:nil];
                return;
            }
            
            range = [URLkeyString rangeOfString:@"ispResult"];
            if( range.location != NSNotFound ) { //ISP 인증 후 결제 진행
                //[MY_APP_URL_KEY length]+3 => ISP 경우  scheme + :// 로 리턴 되어 "://" 도 함께 삭제 함.
                // nicepaysample://://http://web.nicepay.co.kr/smart/card/isp/ .... ispResult.jsp 에서
                // http://web.nicepay.co.kr/smart/card/isp/.... ispResult.jsp" 추출하기 위함
                URLkeyString = [URLkeyString substringFromIndex:[APP_SCHEME length]];
                NSLog(@"URLkeySring: %@", URLkeyString);
                [self resultIsp:URLkeyString];
                return;
            }
        }
    }
}

@end
