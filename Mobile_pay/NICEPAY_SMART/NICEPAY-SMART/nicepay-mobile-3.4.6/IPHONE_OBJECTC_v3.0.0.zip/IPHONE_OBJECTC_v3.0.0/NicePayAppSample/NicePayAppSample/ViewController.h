//
//  ViewController.h
//  NicePayAppSample
//
//  Created by xoghzone on 2019. 1. 9..
//  Copyright © 2019년 Nicepayments. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

