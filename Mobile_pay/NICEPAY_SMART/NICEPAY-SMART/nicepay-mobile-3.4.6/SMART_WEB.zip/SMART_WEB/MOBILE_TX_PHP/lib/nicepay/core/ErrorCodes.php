<?php
/**
 * 
 * @author kblee
 *
 */
class ErrorCodes {
	/* �ý��� */
	const S999 = "S999";
	const S001 = "S001";
	const S002 = "S002";
	  
	/* ���� */
	const T001 = "T001";
	const T002 = "T002";
	const T003 = "T003";
	const T004 = "T004";
	const T005 = "T005";
	const T006 = "T006";
	
	/* ��� */
	const X001 = "X001";
	const X002 = "X002";
	const X003 = "X003";
	const X004 = "X004";
	
	/* ��ȿ�� */
	const V005 = "V005";
	const V101 = "V101";
	const V102 = "V102";
	const V103 = "V103";
	const V104 = "V104";
	const V201 = "V201";
	const V202 = "V202";
	const V203 = "V203";
	//const V204 = "V204";
	const V205 = "V205";
	const V301 = "V301";
	//const V302 = "V302";
	const V303 = "V303";
	const V304 = "V304";
	const V401 = "V401";
	const V402 = "V402";
	const V501 = "V501";
	//const V502 = "V502";
	const V503 = "V503";
	//const V504 = "V504";
	const V505 = "V505";
	const V506 = "V506";
	const V507 = "V507";
	const V508 = "V508";
	//const V509 = "V509";
	const V510 = "V510";
	const V511 = "V511";
	const V512 = "V512";
	const V513 = "V513";
	//const V601 = "V601";
	const V602 = "V602";
	const V701 = "V701";
	const VA01 = "VA01";
	const VA02 = "VA02";
	const VA03 = "VA03";
	const VA04 = "VA04";
	const VA05 = "VA05";
	//const VA06 = "VA06";
	//const VA07 = "VA07";
	//const VA08 = "VA08";
	const VA09 = "VA09";
	const VA10 = "VA10";
	const VA11 = "VA11";
	const VA12 = "VA12";
	const VA13 = "VA13";
	
	const VB02 = "VB02";
	const VB05 = "VB05";
	const VB09 = "VB09";
	const VB10 = "VB10";
	 
	
	const VC01 ="VC01";
	const VC02 ="VC02";
	const VC03 ="VC03";
	const VC04 ="VC04";
	const VC05 ="VC05";
	
	const V801 = "V801";
	const V802 = "V802";
	//const V803 = "V803";
	
}

?>